Visit the Themes section of the Getting Started Guide for information
on creating custom themes for a DrupalGap mobile application.

  http://drupalgap.org/node/84

